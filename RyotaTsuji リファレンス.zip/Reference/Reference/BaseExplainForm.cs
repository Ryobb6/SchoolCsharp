﻿namespace Reference
{
    public partial class BaseExplainForm : Reference.BaseForm
    {
        public BaseExplainForm()
        {
            InitializeComponent();
        }
    }
}
