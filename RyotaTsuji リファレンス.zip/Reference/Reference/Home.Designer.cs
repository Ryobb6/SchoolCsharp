﻿
namespace Reference
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.panel1 = new System.Windows.Forms.Panel();
            this.linkLabel37 = new System.Windows.Forms.LinkLabel();
            this.linkLabel36 = new System.Windows.Forms.LinkLabel();
            this.linkLabel35 = new System.Windows.Forms.LinkLabel();
            this.linkLabel34 = new System.Windows.Forms.LinkLabel();
            this.linkLabel33 = new System.Windows.Forms.LinkLabel();
            this.linkLabel32 = new System.Windows.Forms.LinkLabel();
            this.linkLabel31 = new System.Windows.Forms.LinkLabel();
            this.linkLabel30 = new System.Windows.Forms.LinkLabel();
            this.linkLabel29 = new System.Windows.Forms.LinkLabel();
            this.linkLabel28 = new System.Windows.Forms.LinkLabel();
            this.linkLabel27 = new System.Windows.Forms.LinkLabel();
            this.linkLabel26 = new System.Windows.Forms.LinkLabel();
            this.linkLabel25 = new System.Windows.Forms.LinkLabel();
            this.linkLabel24 = new System.Windows.Forms.LinkLabel();
            this.linkLabel23 = new System.Windows.Forms.LinkLabel();
            this.linkLabel22 = new System.Windows.Forms.LinkLabel();
            this.linkLabel21 = new System.Windows.Forms.LinkLabel();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.linkLabel40 = new System.Windows.Forms.LinkLabel();
            this.linkLabel39 = new System.Windows.Forms.LinkLabel();
            this.linkLabel38 = new System.Windows.Forms.LinkLabel();
            this.linkLabel5 = new System.Windows.Forms.LinkLabel();
            this.linkLabel6 = new System.Windows.Forms.LinkLabel();
            this.linkLabel7 = new System.Windows.Forms.LinkLabel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.linkLabel42 = new System.Windows.Forms.LinkLabel();
            this.linkLabel41 = new System.Windows.Forms.LinkLabel();
            this.linkLabel9 = new System.Windows.Forms.LinkLabel();
            this.linkLabel10 = new System.Windows.Forms.LinkLabel();
            this.linkLabel11 = new System.Windows.Forms.LinkLabel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.linkLabel44 = new System.Windows.Forms.LinkLabel();
            this.linkLabel43 = new System.Windows.Forms.LinkLabel();
            this.linkLabel13 = new System.Windows.Forms.LinkLabel();
            this.linkLabel14 = new System.Windows.Forms.LinkLabel();
            this.linkLabel15 = new System.Windows.Forms.LinkLabel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.linkLabel64 = new System.Windows.Forms.LinkLabel();
            this.linkLabel63 = new System.Windows.Forms.LinkLabel();
            this.linkLabel62 = new System.Windows.Forms.LinkLabel();
            this.linkLabel61 = new System.Windows.Forms.LinkLabel();
            this.linkLabel60 = new System.Windows.Forms.LinkLabel();
            this.linkLabel59 = new System.Windows.Forms.LinkLabel();
            this.linkLabel58 = new System.Windows.Forms.LinkLabel();
            this.linkLabel45 = new System.Windows.Forms.LinkLabel();
            this.linkLabel46 = new System.Windows.Forms.LinkLabel();
            this.linkLabel47 = new System.Windows.Forms.LinkLabel();
            this.linkLabel48 = new System.Windows.Forms.LinkLabel();
            this.linkLabel49 = new System.Windows.Forms.LinkLabel();
            this.linkLabel50 = new System.Windows.Forms.LinkLabel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.linkLabel52 = new System.Windows.Forms.LinkLabel();
            this.linkLabel53 = new System.Windows.Forms.LinkLabel();
            this.linkLabel54 = new System.Windows.Forms.LinkLabel();
            this.linkLabel55 = new System.Windows.Forms.LinkLabel();
            this.linkLabel56 = new System.Windows.Forms.LinkLabel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.linkLabel65 = new System.Windows.Forms.LinkLabel();
            this.linkLabel66 = new System.Windows.Forms.LinkLabel();
            this.linkLabel67 = new System.Windows.Forms.LinkLabel();
            this.linkLabel68 = new System.Windows.Forms.LinkLabel();
            this.linkLabel69 = new System.Windows.Forms.LinkLabel();
            this.label8 = new System.Windows.Forms.Label();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.panel9 = new System.Windows.Forms.Panel();
            this.linkLabel73 = new System.Windows.Forms.LinkLabel();
            this.label9 = new System.Windows.Forms.Label();
            this.panelAllForm = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.linkLabel71 = new System.Windows.Forms.LinkLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ツールボックスToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.コモンコントロールToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.トリガー系ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.linkLabelToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.選択系ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.checkBoxToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.radioButtonToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.listBoxToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.checkedListBoxToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.listViewToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.入力系ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBoxToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.maskedTextBoxToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.richTextBoxToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.numericUpDownToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.日付系ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.datetimePickerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.monthCalenderToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.表示系ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.labelToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBoxToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTipToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.その他ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notifyIconToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.progressBarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.webBrowserToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.コンテナーToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.メニューとツールバーToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.データToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.コンポーネントToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.印刷ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ダイアログToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wPF相互運用機能ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.プロパティToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.イベントToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.よくある質問ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.画像を表示したいToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.再生プレイヤーを埋め込みたいToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.動画再生プレイヤーを埋め込みたいToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panelAllForm.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Azure;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.linkLabel37);
            this.panel1.Controls.Add(this.linkLabel36);
            this.panel1.Controls.Add(this.linkLabel35);
            this.panel1.Controls.Add(this.linkLabel34);
            this.panel1.Controls.Add(this.linkLabel33);
            this.panel1.Controls.Add(this.linkLabel32);
            this.panel1.Controls.Add(this.linkLabel31);
            this.panel1.Controls.Add(this.linkLabel30);
            this.panel1.Controls.Add(this.linkLabel29);
            this.panel1.Controls.Add(this.linkLabel28);
            this.panel1.Controls.Add(this.linkLabel27);
            this.panel1.Controls.Add(this.linkLabel26);
            this.panel1.Controls.Add(this.linkLabel25);
            this.panel1.Controls.Add(this.linkLabel24);
            this.panel1.Controls.Add(this.linkLabel23);
            this.panel1.Controls.Add(this.linkLabel22);
            this.panel1.Controls.Add(this.linkLabel21);
            this.panel1.Controls.Add(this.linkLabel4);
            this.panel1.Controls.Add(this.linkLabel3);
            this.panel1.Controls.Add(this.linkLabel2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 60);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(136, 545);
            this.panel1.TabIndex = 17;
            // 
            // linkLabel37
            // 
            this.linkLabel37.AutoSize = true;
            this.linkLabel37.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.linkLabel37.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel37.Location = new System.Drawing.Point(12, 470);
            this.linkLabel37.Name = "linkLabel37";
            this.linkLabel37.Size = new System.Drawing.Size(68, 12);
            this.linkLabel37.TabIndex = 38;
            this.linkLabel37.TabStop = true;
            this.linkLabel37.Text = "WebBrowser";
            this.linkLabel37.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ExpWebBrowser);
            // 
            // linkLabel36
            // 
            this.linkLabel36.AutoSize = true;
            this.linkLabel36.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.linkLabel36.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel36.Location = new System.Drawing.Point(12, 447);
            this.linkLabel36.Name = "linkLabel36";
            this.linkLabel36.Size = new System.Drawing.Size(53, 12);
            this.linkLabel36.TabIndex = 37;
            this.linkLabel36.TabStop = true;
            this.linkLabel36.Text = "TreeView";
            this.linkLabel36.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ExpTreeView);
            // 
            // linkLabel35
            // 
            this.linkLabel35.AutoSize = true;
            this.linkLabel35.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.linkLabel35.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel35.Location = new System.Drawing.Point(12, 401);
            this.linkLabel35.Name = "linkLabel35";
            this.linkLabel35.Size = new System.Drawing.Size(48, 12);
            this.linkLabel35.TabIndex = 36;
            this.linkLabel35.TabStop = true;
            this.linkLabel35.Text = "TextBox";
            this.linkLabel35.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ExpTextBox);
            // 
            // linkLabel34
            // 
            this.linkLabel34.AutoSize = true;
            this.linkLabel34.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.linkLabel34.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel34.Location = new System.Drawing.Point(12, 424);
            this.linkLabel34.Name = "linkLabel34";
            this.linkLabel34.Size = new System.Drawing.Size(43, 12);
            this.linkLabel34.TabIndex = 35;
            this.linkLabel34.TabStop = true;
            this.linkLabel34.Text = "ToolTip";
            this.linkLabel34.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ExpToolTip);
            // 
            // linkLabel33
            // 
            this.linkLabel33.AutoSize = true;
            this.linkLabel33.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.linkLabel33.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel33.Location = new System.Drawing.Point(12, 378);
            this.linkLabel33.Name = "linkLabel33";
            this.linkLabel33.Size = new System.Drawing.Size(68, 12);
            this.linkLabel33.TabIndex = 34;
            this.linkLabel33.TabStop = true;
            this.linkLabel33.Text = "RadioButton";
            this.linkLabel33.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ExpRadioButton);
            // 
            // linkLabel32
            // 
            this.linkLabel32.AutoSize = true;
            this.linkLabel32.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.linkLabel32.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel32.Location = new System.Drawing.Point(12, 355);
            this.linkLabel32.Name = "linkLabel32";
            this.linkLabel32.Size = new System.Drawing.Size(68, 12);
            this.linkLabel32.TabIndex = 33;
            this.linkLabel32.TabStop = true;
            this.linkLabel32.Text = "ProgressBar";
            this.linkLabel32.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ExpProgressBar);
            // 
            // linkLabel31
            // 
            this.linkLabel31.AutoSize = true;
            this.linkLabel31.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.linkLabel31.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel31.Location = new System.Drawing.Point(12, 332);
            this.linkLabel31.Name = "linkLabel31";
            this.linkLabel31.Size = new System.Drawing.Size(61, 12);
            this.linkLabel31.TabIndex = 32;
            this.linkLabel31.TabStop = true;
            this.linkLabel31.Text = "PictureBox";
            this.linkLabel31.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ExpPictureBox);
            // 
            // linkLabel30
            // 
            this.linkLabel30.AutoSize = true;
            this.linkLabel30.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.linkLabel30.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel30.Location = new System.Drawing.Point(12, 309);
            this.linkLabel30.Name = "linkLabel30";
            this.linkLabel30.Size = new System.Drawing.Size(89, 12);
            this.linkLabel30.TabIndex = 31;
            this.linkLabel30.TabStop = true;
            this.linkLabel30.Text = "NumericUpDown";
            this.linkLabel30.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ExpNumericUpDown);
            // 
            // linkLabel29
            // 
            this.linkLabel29.AutoSize = true;
            this.linkLabel29.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.linkLabel29.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel29.Location = new System.Drawing.Point(12, 286);
            this.linkLabel29.Name = "linkLabel29";
            this.linkLabel29.Size = new System.Drawing.Size(57, 12);
            this.linkLabel29.TabIndex = 30;
            this.linkLabel29.TabStop = true;
            this.linkLabel29.Text = "NotifyIcon";
            this.linkLabel29.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ExpNotifyIcon);
            // 
            // linkLabel28
            // 
            this.linkLabel28.AutoSize = true;
            this.linkLabel28.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.linkLabel28.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel28.Location = new System.Drawing.Point(12, 263);
            this.linkLabel28.Name = "linkLabel28";
            this.linkLabel28.Size = new System.Drawing.Size(81, 12);
            this.linkLabel28.TabIndex = 29;
            this.linkLabel28.TabStop = true;
            this.linkLabel28.Text = "MonthCalendar";
            this.linkLabel28.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ExpMonthCalendarBox);
            // 
            // linkLabel27
            // 
            this.linkLabel27.AutoSize = true;
            this.linkLabel27.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel27.Location = new System.Drawing.Point(12, 240);
            this.linkLabel27.Name = "linkLabel27";
            this.linkLabel27.Size = new System.Drawing.Size(87, 12);
            this.linkLabel27.TabIndex = 28;
            this.linkLabel27.TabStop = true;
            this.linkLabel27.Text = "MaskedTextBox";
            this.linkLabel27.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ExpMaskedTextBox);
            // 
            // linkLabel26
            // 
            this.linkLabel26.AutoSize = true;
            this.linkLabel26.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel26.Location = new System.Drawing.Point(12, 217);
            this.linkLabel26.Name = "linkLabel26";
            this.linkLabel26.Size = new System.Drawing.Size(49, 12);
            this.linkLabel26.TabIndex = 27;
            this.linkLabel26.TabStop = true;
            this.linkLabel26.Text = "ListView";
            this.linkLabel26.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ExpListView);
            // 
            // linkLabel25
            // 
            this.linkLabel25.AutoSize = true;
            this.linkLabel25.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel25.Location = new System.Drawing.Point(12, 194);
            this.linkLabel25.Name = "linkLabel25";
            this.linkLabel25.Size = new System.Drawing.Size(44, 12);
            this.linkLabel25.TabIndex = 26;
            this.linkLabel25.TabStop = true;
            this.linkLabel25.Text = "ListBox";
            this.linkLabel25.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ExpListBox);
            // 
            // linkLabel24
            // 
            this.linkLabel24.AutoSize = true;
            this.linkLabel24.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel24.Location = new System.Drawing.Point(12, 171);
            this.linkLabel24.Name = "linkLabel24";
            this.linkLabel24.Size = new System.Drawing.Size(53, 12);
            this.linkLabel24.TabIndex = 25;
            this.linkLabel24.TabStop = true;
            this.linkLabel24.Text = "LinkLabel";
            this.linkLabel24.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ExpLabelClicked);
            // 
            // linkLabel23
            // 
            this.linkLabel23.AutoSize = true;
            this.linkLabel23.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel23.Location = new System.Drawing.Point(12, 148);
            this.linkLabel23.Name = "linkLabel23";
            this.linkLabel23.Size = new System.Drawing.Size(32, 12);
            this.linkLabel23.TabIndex = 24;
            this.linkLabel23.TabStop = true;
            this.linkLabel23.Text = "Label";
            this.linkLabel23.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ExpLabelClicked);
            // 
            // linkLabel22
            // 
            this.linkLabel22.AutoSize = true;
            this.linkLabel22.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel22.Location = new System.Drawing.Point(12, 125);
            this.linkLabel22.Name = "linkLabel22";
            this.linkLabel22.Size = new System.Drawing.Size(86, 12);
            this.linkLabel22.TabIndex = 23;
            this.linkLabel22.TabStop = true;
            this.linkLabel22.Text = "DateTimePicker";
            this.linkLabel22.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ExpDateTimePickerClicked);
            // 
            // linkLabel21
            // 
            this.linkLabel21.AutoSize = true;
            this.linkLabel21.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel21.Location = new System.Drawing.Point(12, 102);
            this.linkLabel21.Name = "linkLabel21";
            this.linkLabel21.Size = new System.Drawing.Size(60, 12);
            this.linkLabel21.TabIndex = 22;
            this.linkLabel21.TabStop = true;
            this.linkLabel21.Text = "ComboBox";
            this.linkLabel21.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ExpConboBoxClicked);
            // 
            // linkLabel4
            // 
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel4.Location = new System.Drawing.Point(12, 79);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(88, 12);
            this.linkLabel4.TabIndex = 21;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Text = "CheckedListBox";
            this.linkLabel4.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.EcpCheckedListBox);
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel3.Location = new System.Drawing.Point(12, 56);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(57, 12);
            this.linkLabel3.TabIndex = 20;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "CheckBox";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ExpCheckBoxClicked);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel2.Location = new System.Drawing.Point(12, 33);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(39, 12);
            this.linkLabel2.TabIndex = 19;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Button";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ButtonLinkClicked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(12, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "コモンコントロール";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Lavender;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.linkLabel40);
            this.panel2.Controls.Add(this.linkLabel39);
            this.panel2.Controls.Add(this.linkLabel38);
            this.panel2.Controls.Add(this.linkLabel5);
            this.panel2.Controls.Add(this.linkLabel6);
            this.panel2.Controls.Add(this.linkLabel7);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(166, 60);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(136, 195);
            this.panel2.TabIndex = 22;
            // 
            // linkLabel40
            // 
            this.linkLabel40.AutoSize = true;
            this.linkLabel40.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel40.Location = new System.Drawing.Point(12, 147);
            this.linkLabel40.Name = "linkLabel40";
            this.linkLabel40.Size = new System.Drawing.Size(86, 12);
            this.linkLabel40.TabIndex = 24;
            this.linkLabel40.TabStop = true;
            this.linkLabel40.Text = "TabLayoutPanel";
            // 
            // linkLabel39
            // 
            this.linkLabel39.AutoSize = true;
            this.linkLabel39.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel39.Location = new System.Drawing.Point(12, 124);
            this.linkLabel39.Name = "linkLabel39";
            this.linkLabel39.Size = new System.Drawing.Size(61, 12);
            this.linkLabel39.TabIndex = 23;
            this.linkLabel39.TabStop = true;
            this.linkLabel39.Text = "TabControl";
            // 
            // linkLabel38
            // 
            this.linkLabel38.AutoSize = true;
            this.linkLabel38.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel38.Location = new System.Drawing.Point(12, 101);
            this.linkLabel38.Name = "linkLabel38";
            this.linkLabel38.Size = new System.Drawing.Size(77, 12);
            this.linkLabel38.TabIndex = 22;
            this.linkLabel38.TabStop = true;
            this.linkLabel38.Text = "SplitContainer";
            // 
            // linkLabel5
            // 
            this.linkLabel5.AutoSize = true;
            this.linkLabel5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel5.Location = new System.Drawing.Point(12, 78);
            this.linkLabel5.Name = "linkLabel5";
            this.linkLabel5.Size = new System.Drawing.Size(33, 12);
            this.linkLabel5.TabIndex = 21;
            this.linkLabel5.TabStop = true;
            this.linkLabel5.Text = "Panel";
            // 
            // linkLabel6
            // 
            this.linkLabel6.AutoSize = true;
            this.linkLabel6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel6.Location = new System.Drawing.Point(12, 55);
            this.linkLabel6.Name = "linkLabel6";
            this.linkLabel6.Size = new System.Drawing.Size(55, 12);
            this.linkLabel6.TabIndex = 20;
            this.linkLabel6.TabStop = true;
            this.linkLabel6.Text = "GroupBox";
            // 
            // linkLabel7
            // 
            this.linkLabel7.AutoSize = true;
            this.linkLabel7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel7.Location = new System.Drawing.Point(12, 32);
            this.linkLabel7.Name = "linkLabel7";
            this.linkLabel7.Size = new System.Drawing.Size(91, 12);
            this.linkLabel7.TabIndex = 19;
            this.linkLabel7.TabStop = true;
            this.linkLabel7.Text = "FlowLayoutPanel";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(12, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "コンテナー";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Azure;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.linkLabel42);
            this.panel3.Controls.Add(this.linkLabel41);
            this.panel3.Controls.Add(this.linkLabel9);
            this.panel3.Controls.Add(this.linkLabel10);
            this.panel3.Controls.Add(this.linkLabel11);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(320, 60);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(136, 195);
            this.panel3.TabIndex = 23;
            // 
            // linkLabel42
            // 
            this.linkLabel42.AutoSize = true;
            this.linkLabel42.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel42.Location = new System.Drawing.Point(12, 123);
            this.linkLabel42.Name = "linkLabel42";
            this.linkLabel42.Size = new System.Drawing.Size(100, 12);
            this.linkLabel42.TabIndex = 23;
            this.linkLabel42.TabStop = true;
            this.linkLabel42.Text = "ToolStripContainer";
            // 
            // linkLabel41
            // 
            this.linkLabel41.AutoSize = true;
            this.linkLabel41.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel41.Location = new System.Drawing.Point(12, 100);
            this.linkLabel41.Name = "linkLabel41";
            this.linkLabel41.Size = new System.Drawing.Size(51, 12);
            this.linkLabel41.TabIndex = 22;
            this.linkLabel41.TabStop = true;
            this.linkLabel41.Text = "ToolStrip";
            // 
            // linkLabel9
            // 
            this.linkLabel9.AutoSize = true;
            this.linkLabel9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel9.Location = new System.Drawing.Point(12, 77);
            this.linkLabel9.Name = "linkLabel9";
            this.linkLabel9.Size = new System.Drawing.Size(62, 12);
            this.linkLabel9.TabIndex = 21;
            this.linkLabel9.TabStop = true;
            this.linkLabel9.Text = "StatusStrip";
            // 
            // linkLabel10
            // 
            this.linkLabel10.AutoSize = true;
            this.linkLabel10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel10.Location = new System.Drawing.Point(12, 54);
            this.linkLabel10.Name = "linkLabel10";
            this.linkLabel10.Size = new System.Drawing.Size(56, 12);
            this.linkLabel10.TabIndex = 20;
            this.linkLabel10.TabStop = true;
            this.linkLabel10.Text = "MenuStrip";
            // 
            // linkLabel11
            // 
            this.linkLabel11.AutoSize = true;
            this.linkLabel11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel11.Location = new System.Drawing.Point(12, 31);
            this.linkLabel11.Name = "linkLabel11";
            this.linkLabel11.Size = new System.Drawing.Size(96, 12);
            this.linkLabel11.TabIndex = 19;
            this.linkLabel11.TabStop = true;
            this.linkLabel11.Text = "ContextMenuStrip";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(12, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 12);
            this.label3.TabIndex = 1;
            this.label3.Text = "メニューとツールバー";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Lavender;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.linkLabel44);
            this.panel4.Controls.Add(this.linkLabel43);
            this.panel4.Controls.Add(this.linkLabel13);
            this.panel4.Controls.Add(this.linkLabel14);
            this.panel4.Controls.Add(this.linkLabel15);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Location = new System.Drawing.Point(474, 60);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(136, 195);
            this.panel4.TabIndex = 24;
            // 
            // linkLabel44
            // 
            this.linkLabel44.AutoSize = true;
            this.linkLabel44.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel44.Location = new System.Drawing.Point(12, 123);
            this.linkLabel44.Name = "linkLabel44";
            this.linkLabel44.Size = new System.Drawing.Size(46, 12);
            this.linkLabel44.TabIndex = 23;
            this.linkLabel44.TabStop = true;
            this.linkLabel44.Text = "DataSet";
            // 
            // linkLabel43
            // 
            this.linkLabel43.AutoSize = true;
            this.linkLabel43.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel43.Location = new System.Drawing.Point(12, 100);
            this.linkLabel43.Name = "linkLabel43";
            this.linkLabel43.Size = new System.Drawing.Size(75, 12);
            this.linkLabel43.TabIndex = 22;
            this.linkLabel43.TabStop = true;
            this.linkLabel43.Text = "DataGridView";
            // 
            // linkLabel13
            // 
            this.linkLabel13.AutoSize = true;
            this.linkLabel13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel13.Location = new System.Drawing.Point(12, 77);
            this.linkLabel13.Name = "linkLabel13";
            this.linkLabel13.Size = new System.Drawing.Size(78, 12);
            this.linkLabel13.TabIndex = 21;
            this.linkLabel13.TabStop = true;
            this.linkLabel13.Text = "BindingSource";
            // 
            // linkLabel14
            // 
            this.linkLabel14.AutoSize = true;
            this.linkLabel14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel14.Location = new System.Drawing.Point(12, 54);
            this.linkLabel14.Name = "linkLabel14";
            this.linkLabel14.Size = new System.Drawing.Size(92, 12);
            this.linkLabel14.TabIndex = 20;
            this.linkLabel14.TabStop = true;
            this.linkLabel14.Text = "BindingNavigator";
            // 
            // linkLabel15
            // 
            this.linkLabel15.AutoSize = true;
            this.linkLabel15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel15.Location = new System.Drawing.Point(12, 31);
            this.linkLabel15.Name = "linkLabel15";
            this.linkLabel15.Size = new System.Drawing.Size(33, 12);
            this.linkLabel15.TabIndex = 19;
            this.linkLabel15.TabStop = true;
            this.linkLabel15.Text = "Chart";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(12, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 12);
            this.label4.TabIndex = 1;
            this.label4.Text = "データ";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Lavender;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.linkLabel64);
            this.panel6.Controls.Add(this.linkLabel63);
            this.panel6.Controls.Add(this.linkLabel62);
            this.panel6.Controls.Add(this.linkLabel61);
            this.panel6.Controls.Add(this.linkLabel60);
            this.panel6.Controls.Add(this.linkLabel59);
            this.panel6.Controls.Add(this.linkLabel58);
            this.panel6.Controls.Add(this.linkLabel45);
            this.panel6.Controls.Add(this.linkLabel46);
            this.panel6.Controls.Add(this.linkLabel47);
            this.panel6.Controls.Add(this.linkLabel48);
            this.panel6.Controls.Add(this.linkLabel49);
            this.panel6.Controls.Add(this.linkLabel50);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Location = new System.Drawing.Point(166, 261);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(136, 344);
            this.panel6.TabIndex = 25;
            // 
            // linkLabel64
            // 
            this.linkLabel64.AutoSize = true;
            this.linkLabel64.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel64.Location = new System.Drawing.Point(12, 296);
            this.linkLabel64.Name = "linkLabel64";
            this.linkLabel64.Size = new System.Drawing.Size(34, 12);
            this.linkLabel64.TabIndex = 31;
            this.linkLabel64.TabStop = true;
            this.linkLabel64.Text = "Timer";
            // 
            // linkLabel63
            // 
            this.linkLabel63.AutoSize = true;
            this.linkLabel63.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel63.Location = new System.Drawing.Point(12, 274);
            this.linkLabel63.Name = "linkLabel63";
            this.linkLabel63.Size = new System.Drawing.Size(93, 12);
            this.linkLabel63.TabIndex = 30;
            this.linkLabel63.TabStop = true;
            this.linkLabel63.Text = "ServiceController";
            // 
            // linkLabel62
            // 
            this.linkLabel62.AutoSize = true;
            this.linkLabel62.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel62.Location = new System.Drawing.Point(12, 252);
            this.linkLabel62.Name = "linkLabel62";
            this.linkLabel62.Size = new System.Drawing.Size(55, 12);
            this.linkLabel62.TabIndex = 29;
            this.linkLabel62.TabStop = true;
            this.linkLabel62.Text = "SerialPort";
            // 
            // linkLabel61
            // 
            this.linkLabel61.AutoSize = true;
            this.linkLabel61.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel61.Location = new System.Drawing.Point(12, 230);
            this.linkLabel61.Name = "linkLabel61";
            this.linkLabel61.Size = new System.Drawing.Size(46, 12);
            this.linkLabel61.TabIndex = 28;
            this.linkLabel61.TabStop = true;
            this.linkLabel61.Text = "Process";
            // 
            // linkLabel60
            // 
            this.linkLabel60.AutoSize = true;
            this.linkLabel60.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel60.Location = new System.Drawing.Point(12, 208);
            this.linkLabel60.Name = "linkLabel60";
            this.linkLabel60.Size = new System.Drawing.Size(109, 12);
            this.linkLabel60.TabIndex = 27;
            this.linkLabel60.TabStop = true;
            this.linkLabel60.Text = "PerformanceCounter";
            // 
            // linkLabel59
            // 
            this.linkLabel59.AutoSize = true;
            this.linkLabel59.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel59.Location = new System.Drawing.Point(12, 186);
            this.linkLabel59.Name = "linkLabel59";
            this.linkLabel59.Size = new System.Drawing.Size(82, 12);
            this.linkLabel59.TabIndex = 26;
            this.linkLabel59.TabStop = true;
            this.linkLabel59.Text = "MessageQueue";
            // 
            // linkLabel58
            // 
            this.linkLabel58.AutoSize = true;
            this.linkLabel58.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel58.Location = new System.Drawing.Point(12, 164);
            this.linkLabel58.Name = "linkLabel58";
            this.linkLabel58.Size = new System.Drawing.Size(54, 12);
            this.linkLabel58.TabIndex = 25;
            this.linkLabel58.TabStop = true;
            this.linkLabel58.Text = "ImageList";
            // 
            // linkLabel45
            // 
            this.linkLabel45.AutoSize = true;
            this.linkLabel45.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel45.Location = new System.Drawing.Point(12, 142);
            this.linkLabel45.Name = "linkLabel45";
            this.linkLabel45.Size = new System.Drawing.Size(103, 12);
            this.linkLabel45.TabIndex = 24;
            this.linkLabel45.TabStop = true;
            this.linkLabel45.Text = "FileSystemWatcher";
            // 
            // linkLabel46
            // 
            this.linkLabel46.AutoSize = true;
            this.linkLabel46.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel46.Location = new System.Drawing.Point(12, 120);
            this.linkLabel46.Name = "linkLabel46";
            this.linkLabel46.Size = new System.Drawing.Size(52, 12);
            this.linkLabel46.TabIndex = 23;
            this.linkLabel46.TabStop = true;
            this.linkLabel46.Text = "EventLog";
            // 
            // linkLabel47
            // 
            this.linkLabel47.AutoSize = true;
            this.linkLabel47.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel47.Location = new System.Drawing.Point(12, 98);
            this.linkLabel47.Name = "linkLabel47";
            this.linkLabel47.Size = new System.Drawing.Size(72, 12);
            this.linkLabel47.TabIndex = 22;
            this.linkLabel47.TabStop = true;
            this.linkLabel47.Text = "ErrorProvider";
            // 
            // linkLabel48
            // 
            this.linkLabel48.AutoSize = true;
            this.linkLabel48.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel48.Location = new System.Drawing.Point(12, 76);
            this.linkLabel48.Name = "linkLabel48";
            this.linkLabel48.Size = new System.Drawing.Size(97, 12);
            this.linkLabel48.TabIndex = 21;
            this.linkLabel48.TabStop = true;
            this.linkLabel48.Text = "DirectorySearcher";
            // 
            // linkLabel49
            // 
            this.linkLabel49.AutoSize = true;
            this.linkLabel49.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel49.Location = new System.Drawing.Point(12, 54);
            this.linkLabel49.Name = "linkLabel49";
            this.linkLabel49.Size = new System.Drawing.Size(79, 12);
            this.linkLabel49.TabIndex = 20;
            this.linkLabel49.TabStop = true;
            this.linkLabel49.Text = "DirectoryEntry";
            // 
            // linkLabel50
            // 
            this.linkLabel50.AutoSize = true;
            this.linkLabel50.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel50.Location = new System.Drawing.Point(12, 32);
            this.linkLabel50.Name = "linkLabel50";
            this.linkLabel50.Size = new System.Drawing.Size(102, 12);
            this.linkLabel50.TabIndex = 19;
            this.linkLabel50.TabStop = true;
            this.linkLabel50.Text = "BackGroundWorker";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(12, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 12);
            this.label6.TabIndex = 1;
            this.label6.Text = "コンポーネント";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Azure;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.linkLabel52);
            this.panel7.Controls.Add(this.linkLabel53);
            this.panel7.Controls.Add(this.linkLabel54);
            this.panel7.Controls.Add(this.linkLabel55);
            this.panel7.Controls.Add(this.linkLabel56);
            this.panel7.Controls.Add(this.label7);
            this.panel7.Location = new System.Drawing.Point(320, 261);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(136, 177);
            this.panel7.TabIndex = 24;
            // 
            // linkLabel52
            // 
            this.linkLabel52.AutoSize = true;
            this.linkLabel52.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel52.Location = new System.Drawing.Point(12, 124);
            this.linkLabel52.Name = "linkLabel52";
            this.linkLabel52.Size = new System.Drawing.Size(101, 12);
            this.linkLabel52.TabIndex = 23;
            this.linkLabel52.TabStop = true;
            this.linkLabel52.Text = "PrintPreviewDialog";
            // 
            // linkLabel53
            // 
            this.linkLabel53.AutoSize = true;
            this.linkLabel53.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel53.Location = new System.Drawing.Point(12, 101);
            this.linkLabel53.Name = "linkLabel53";
            this.linkLabel53.Size = new System.Drawing.Size(106, 12);
            this.linkLabel53.TabIndex = 22;
            this.linkLabel53.TabStop = true;
            this.linkLabel53.Text = "PrintPreviewControl";
            // 
            // linkLabel54
            // 
            this.linkLabel54.AutoSize = true;
            this.linkLabel54.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel54.Location = new System.Drawing.Point(12, 78);
            this.linkLabel54.Name = "linkLabel54";
            this.linkLabel54.Size = new System.Drawing.Size(80, 12);
            this.linkLabel54.TabIndex = 21;
            this.linkLabel54.TabStop = true;
            this.linkLabel54.Text = "PrintDocument";
            // 
            // linkLabel55
            // 
            this.linkLabel55.AutoSize = true;
            this.linkLabel55.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel55.Location = new System.Drawing.Point(12, 55);
            this.linkLabel55.Name = "linkLabel55";
            this.linkLabel55.Size = new System.Drawing.Size(61, 12);
            this.linkLabel55.TabIndex = 20;
            this.linkLabel55.TabStop = true;
            this.linkLabel55.Text = "PrintDialog";
            // 
            // linkLabel56
            // 
            this.linkLabel56.AutoSize = true;
            this.linkLabel56.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel56.Location = new System.Drawing.Point(12, 32);
            this.linkLabel56.Name = "linkLabel56";
            this.linkLabel56.Size = new System.Drawing.Size(91, 12);
            this.linkLabel56.TabIndex = 19;
            this.linkLabel56.TabStop = true;
            this.linkLabel56.Text = "PageSetupDialog";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(12, 11);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 1;
            this.label7.Text = "印刷";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Lavender;
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.linkLabel65);
            this.panel8.Controls.Add(this.linkLabel66);
            this.panel8.Controls.Add(this.linkLabel67);
            this.panel8.Controls.Add(this.linkLabel68);
            this.panel8.Controls.Add(this.linkLabel69);
            this.panel8.Controls.Add(this.label8);
            this.panel8.Location = new System.Drawing.Point(474, 261);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(136, 177);
            this.panel8.TabIndex = 25;
            // 
            // linkLabel65
            // 
            this.linkLabel65.AutoSize = true;
            this.linkLabel65.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel65.Location = new System.Drawing.Point(12, 123);
            this.linkLabel65.Name = "linkLabel65";
            this.linkLabel65.Size = new System.Drawing.Size(81, 12);
            this.linkLabel65.TabIndex = 23;
            this.linkLabel65.TabStop = true;
            this.linkLabel65.Text = "SaveFileDialog";
            // 
            // linkLabel66
            // 
            this.linkLabel66.AutoSize = true;
            this.linkLabel66.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel66.Location = new System.Drawing.Point(12, 100);
            this.linkLabel66.Name = "linkLabel66";
            this.linkLabel66.Size = new System.Drawing.Size(82, 12);
            this.linkLabel66.TabIndex = 22;
            this.linkLabel66.TabStop = true;
            this.linkLabel66.Text = "OpenFileDialog";
            // 
            // linkLabel67
            // 
            this.linkLabel67.AutoSize = true;
            this.linkLabel67.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel67.Location = new System.Drawing.Point(12, 77);
            this.linkLabel67.Name = "linkLabel67";
            this.linkLabel67.Size = new System.Drawing.Size(60, 12);
            this.linkLabel67.TabIndex = 21;
            this.linkLabel67.TabStop = true;
            this.linkLabel67.Text = "FontDialog";
            // 
            // linkLabel68
            // 
            this.linkLabel68.AutoSize = true;
            this.linkLabel68.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel68.Location = new System.Drawing.Point(12, 54);
            this.linkLabel68.Name = "linkLabel68";
            this.linkLabel68.Size = new System.Drawing.Size(111, 12);
            this.linkLabel68.TabIndex = 20;
            this.linkLabel68.TabStop = true;
            this.linkLabel68.Text = "FolderBrowserDialog";
            // 
            // linkLabel69
            // 
            this.linkLabel69.AutoSize = true;
            this.linkLabel69.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel69.Location = new System.Drawing.Point(12, 31);
            this.linkLabel69.Name = "linkLabel69";
            this.linkLabel69.Size = new System.Drawing.Size(64, 12);
            this.linkLabel69.TabIndex = 19;
            this.linkLabel69.TabStop = true;
            this.linkLabel69.Text = "ColorDialog";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(12, 11);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 12);
            this.label8.TabIndex = 1;
            this.label8.Text = "ダイアログ";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Azure;
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.linkLabel73);
            this.panel9.Controls.Add(this.label9);
            this.panel9.Location = new System.Drawing.Point(320, 444);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(136, 60);
            this.panel9.TabIndex = 26;
            // 
            // linkLabel73
            // 
            this.linkLabel73.AutoSize = true;
            this.linkLabel73.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel73.Location = new System.Drawing.Point(12, 29);
            this.linkLabel73.Name = "linkLabel73";
            this.linkLabel73.Size = new System.Drawing.Size(70, 12);
            this.linkLabel73.TabIndex = 19;
            this.linkLabel73.TabStop = true;
            this.linkLabel73.Text = "ElementHost";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label9.Location = new System.Drawing.Point(12, 11);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 12);
            this.label9.TabIndex = 1;
            this.label9.Text = "WPF相互運用機能";
            // 
            // panelAllForm
            // 
            this.panelAllForm.Controls.Add(this.linkLabel1);
            this.panelAllForm.Controls.Add(this.label10);
            this.panelAllForm.Controls.Add(this.linkLabel71);
            this.panelAllForm.Location = new System.Drawing.Point(0, 24);
            this.panelAllForm.Name = "panelAllForm";
            this.panelAllForm.Size = new System.Drawing.Size(629, 582);
            this.panelAllForm.TabIndex = 27;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(16, 10);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(116, 12);
            this.label10.TabIndex = 1;
            this.label10.Text = "全てのWindowsフォーム";
            // 
            // linkLabel71
            // 
            this.linkLabel71.AutoSize = true;
            this.linkLabel71.Location = new System.Drawing.Point(148, 10);
            this.linkLabel71.Name = "linkLabel71";
            this.linkLabel71.Size = new System.Drawing.Size(41, 12);
            this.linkLabel71.TabIndex = 0;
            this.linkLabel71.TabStop = true;
            this.linkLabel71.Text = "イベント";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.menuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ツールボックスToolStripMenuItem,
            this.プロパティToolStripMenuItem,
            this.イベントToolStripMenuItem,
            this.よくある質問ToolStripMenuItem,
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(629, 24);
            this.menuStrip1.TabIndex = 15;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ツールボックスToolStripMenuItem
            // 
            this.ツールボックスToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.コモンコントロールToolStripMenuItem,
            this.コンテナーToolStripMenuItem,
            this.メニューとツールバーToolStripMenuItem,
            this.データToolStripMenuItem,
            this.コンポーネントToolStripMenuItem,
            this.印刷ToolStripMenuItem,
            this.ダイアログToolStripMenuItem,
            this.wPF相互運用機能ToolStripMenuItem});
            this.ツールボックスToolStripMenuItem.Name = "ツールボックスToolStripMenuItem";
            this.ツールボックスToolStripMenuItem.Size = new System.Drawing.Size(82, 20);
            this.ツールボックスToolStripMenuItem.Text = "ツールボックス";
            // 
            // コモンコントロールToolStripMenuItem
            // 
            this.コモンコントロールToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.トリガー系ToolStripMenuItem,
            this.選択系ToolStripMenuItem,
            this.入力系ToolStripMenuItem,
            this.日付系ToolStripMenuItem,
            this.表示系ToolStripMenuItem,
            this.その他ToolStripMenuItem});
            this.コモンコントロールToolStripMenuItem.Name = "コモンコントロールToolStripMenuItem";
            this.コモンコントロールToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.コモンコントロールToolStripMenuItem.Text = "コモンコントロール";
            // 
            // トリガー系ToolStripMenuItem
            // 
            this.トリガー系ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonToolStripMenuItem1,
            this.linkLabelToolStripMenuItem1});
            this.トリガー系ToolStripMenuItem.Name = "トリガー系ToolStripMenuItem";
            this.トリガー系ToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.トリガー系ToolStripMenuItem.Text = "トリガー系";
            // 
            // buttonToolStripMenuItem1
            // 
            this.buttonToolStripMenuItem1.Name = "buttonToolStripMenuItem1";
            this.buttonToolStripMenuItem1.Size = new System.Drawing.Size(124, 22);
            this.buttonToolStripMenuItem1.Text = "Button";
            // 
            // linkLabelToolStripMenuItem1
            // 
            this.linkLabelToolStripMenuItem1.Name = "linkLabelToolStripMenuItem1";
            this.linkLabelToolStripMenuItem1.Size = new System.Drawing.Size(124, 22);
            this.linkLabelToolStripMenuItem1.Text = "LinkLabel";
            // 
            // 選択系ToolStripMenuItem
            // 
            this.選択系ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.checkBoxToolStripMenuItem1,
            this.radioButtonToolStripMenuItem2,
            this.listBoxToolStripMenuItem2,
            this.checkedListBoxToolStripMenuItem2,
            this.listViewToolStripMenuItem1});
            this.選択系ToolStripMenuItem.Name = "選択系ToolStripMenuItem";
            this.選択系ToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.選択系ToolStripMenuItem.Text = "選択系";
            // 
            // checkBoxToolStripMenuItem1
            // 
            this.checkBoxToolStripMenuItem1.Name = "checkBoxToolStripMenuItem1";
            this.checkBoxToolStripMenuItem1.Size = new System.Drawing.Size(157, 22);
            this.checkBoxToolStripMenuItem1.Text = "CheckBox";
            // 
            // radioButtonToolStripMenuItem2
            // 
            this.radioButtonToolStripMenuItem2.Name = "radioButtonToolStripMenuItem2";
            this.radioButtonToolStripMenuItem2.Size = new System.Drawing.Size(157, 22);
            this.radioButtonToolStripMenuItem2.Text = "RadioButton";
            // 
            // listBoxToolStripMenuItem2
            // 
            this.listBoxToolStripMenuItem2.Name = "listBoxToolStripMenuItem2";
            this.listBoxToolStripMenuItem2.Size = new System.Drawing.Size(157, 22);
            this.listBoxToolStripMenuItem2.Text = "ListBox";
            // 
            // checkedListBoxToolStripMenuItem2
            // 
            this.checkedListBoxToolStripMenuItem2.Name = "checkedListBoxToolStripMenuItem2";
            this.checkedListBoxToolStripMenuItem2.Size = new System.Drawing.Size(157, 22);
            this.checkedListBoxToolStripMenuItem2.Text = "CheckedListBox";
            // 
            // listViewToolStripMenuItem1
            // 
            this.listViewToolStripMenuItem1.Name = "listViewToolStripMenuItem1";
            this.listViewToolStripMenuItem1.Size = new System.Drawing.Size(157, 22);
            this.listViewToolStripMenuItem1.Text = "ListView";
            // 
            // 入力系ToolStripMenuItem
            // 
            this.入力系ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.textBoxToolStripMenuItem1,
            this.maskedTextBoxToolStripMenuItem1,
            this.richTextBoxToolStripMenuItem1,
            this.numericUpDownToolStripMenuItem1});
            this.入力系ToolStripMenuItem.Name = "入力系ToolStripMenuItem";
            this.入力系ToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.入力系ToolStripMenuItem.Text = "入力系";
            // 
            // textBoxToolStripMenuItem1
            // 
            this.textBoxToolStripMenuItem1.Name = "textBoxToolStripMenuItem1";
            this.textBoxToolStripMenuItem1.Size = new System.Drawing.Size(165, 22);
            this.textBoxToolStripMenuItem1.Text = "TextBox";
            // 
            // maskedTextBoxToolStripMenuItem1
            // 
            this.maskedTextBoxToolStripMenuItem1.Name = "maskedTextBoxToolStripMenuItem1";
            this.maskedTextBoxToolStripMenuItem1.Size = new System.Drawing.Size(165, 22);
            this.maskedTextBoxToolStripMenuItem1.Text = "MaskedTextBox";
            // 
            // richTextBoxToolStripMenuItem1
            // 
            this.richTextBoxToolStripMenuItem1.Name = "richTextBoxToolStripMenuItem1";
            this.richTextBoxToolStripMenuItem1.Size = new System.Drawing.Size(165, 22);
            this.richTextBoxToolStripMenuItem1.Text = "RichTextBox";
            // 
            // numericUpDownToolStripMenuItem1
            // 
            this.numericUpDownToolStripMenuItem1.Name = "numericUpDownToolStripMenuItem1";
            this.numericUpDownToolStripMenuItem1.Size = new System.Drawing.Size(165, 22);
            this.numericUpDownToolStripMenuItem1.Text = "NumericUpDown";
            // 
            // 日付系ToolStripMenuItem
            // 
            this.日付系ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.datetimePickerToolStripMenuItem1,
            this.monthCalenderToolStripMenuItem1});
            this.日付系ToolStripMenuItem.Name = "日付系ToolStripMenuItem";
            this.日付系ToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.日付系ToolStripMenuItem.Text = "日付系";
            // 
            // datetimePickerToolStripMenuItem1
            // 
            this.datetimePickerToolStripMenuItem1.Name = "datetimePickerToolStripMenuItem1";
            this.datetimePickerToolStripMenuItem1.Size = new System.Drawing.Size(156, 22);
            this.datetimePickerToolStripMenuItem1.Text = "DatetimePicker";
            // 
            // monthCalenderToolStripMenuItem1
            // 
            this.monthCalenderToolStripMenuItem1.Name = "monthCalenderToolStripMenuItem1";
            this.monthCalenderToolStripMenuItem1.Size = new System.Drawing.Size(156, 22);
            this.monthCalenderToolStripMenuItem1.Text = "MonthCalender";
            // 
            // 表示系ToolStripMenuItem
            // 
            this.表示系ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelToolStripMenuItem1,
            this.pictureBoxToolStripMenuItem1,
            this.toolTipToolStripMenuItem1});
            this.表示系ToolStripMenuItem.Name = "表示系ToolStripMenuItem";
            this.表示系ToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.表示系ToolStripMenuItem.Text = "表示系";
            // 
            // labelToolStripMenuItem1
            // 
            this.labelToolStripMenuItem1.Name = "labelToolStripMenuItem1";
            this.labelToolStripMenuItem1.Size = new System.Drawing.Size(131, 22);
            this.labelToolStripMenuItem1.Text = "Label";
            // 
            // pictureBoxToolStripMenuItem1
            // 
            this.pictureBoxToolStripMenuItem1.Name = "pictureBoxToolStripMenuItem1";
            this.pictureBoxToolStripMenuItem1.Size = new System.Drawing.Size(131, 22);
            this.pictureBoxToolStripMenuItem1.Text = "PictureBox";
            // 
            // toolTipToolStripMenuItem1
            // 
            this.toolTipToolStripMenuItem1.Name = "toolTipToolStripMenuItem1";
            this.toolTipToolStripMenuItem1.Size = new System.Drawing.Size(131, 22);
            this.toolTipToolStripMenuItem1.Text = "ToolTip";
            // 
            // その他ToolStripMenuItem
            // 
            this.その他ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.notifyIconToolStripMenuItem1,
            this.progressBarToolStripMenuItem1,
            this.webBrowserToolStripMenuItem1});
            this.その他ToolStripMenuItem.Name = "その他ToolStripMenuItem";
            this.その他ToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.その他ToolStripMenuItem.Text = "その他";
            // 
            // notifyIconToolStripMenuItem1
            // 
            this.notifyIconToolStripMenuItem1.Name = "notifyIconToolStripMenuItem1";
            this.notifyIconToolStripMenuItem1.Size = new System.Drawing.Size(140, 22);
            this.notifyIconToolStripMenuItem1.Text = "NotifyIcon";
            // 
            // progressBarToolStripMenuItem1
            // 
            this.progressBarToolStripMenuItem1.Name = "progressBarToolStripMenuItem1";
            this.progressBarToolStripMenuItem1.Size = new System.Drawing.Size(140, 22);
            this.progressBarToolStripMenuItem1.Text = "ProgressBar";
            // 
            // webBrowserToolStripMenuItem1
            // 
            this.webBrowserToolStripMenuItem1.Name = "webBrowserToolStripMenuItem1";
            this.webBrowserToolStripMenuItem1.Size = new System.Drawing.Size(140, 22);
            this.webBrowserToolStripMenuItem1.Text = "WebBrowser";
            // 
            // コンテナーToolStripMenuItem
            // 
            this.コンテナーToolStripMenuItem.Name = "コンテナーToolStripMenuItem";
            this.コンテナーToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.コンテナーToolStripMenuItem.Text = "コンテナー";
            // 
            // メニューとツールバーToolStripMenuItem
            // 
            this.メニューとツールバーToolStripMenuItem.Name = "メニューとツールバーToolStripMenuItem";
            this.メニューとツールバーToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.メニューとツールバーToolStripMenuItem.Text = "メニューとツールバー";
            // 
            // データToolStripMenuItem
            // 
            this.データToolStripMenuItem.Name = "データToolStripMenuItem";
            this.データToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.データToolStripMenuItem.Text = "データ";
            // 
            // コンポーネントToolStripMenuItem
            // 
            this.コンポーネントToolStripMenuItem.Name = "コンポーネントToolStripMenuItem";
            this.コンポーネントToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.コンポーネントToolStripMenuItem.Text = "コンポーネント";
            // 
            // 印刷ToolStripMenuItem
            // 
            this.印刷ToolStripMenuItem.Name = "印刷ToolStripMenuItem";
            this.印刷ToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.印刷ToolStripMenuItem.Text = "印刷";
            // 
            // ダイアログToolStripMenuItem
            // 
            this.ダイアログToolStripMenuItem.Name = "ダイアログToolStripMenuItem";
            this.ダイアログToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.ダイアログToolStripMenuItem.Text = "ダイアログ";
            // 
            // wPF相互運用機能ToolStripMenuItem
            // 
            this.wPF相互運用機能ToolStripMenuItem.Name = "wPF相互運用機能ToolStripMenuItem";
            this.wPF相互運用機能ToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.wPF相互運用機能ToolStripMenuItem.Text = "WPF相互運用機能";
            // 
            // プロパティToolStripMenuItem
            // 
            this.プロパティToolStripMenuItem.Name = "プロパティToolStripMenuItem";
            this.プロパティToolStripMenuItem.Size = new System.Drawing.Size(63, 20);
            this.プロパティToolStripMenuItem.Text = "プロパティ";
            // 
            // イベントToolStripMenuItem
            // 
            this.イベントToolStripMenuItem.Name = "イベントToolStripMenuItem";
            this.イベントToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.イベントToolStripMenuItem.Text = "イベント";
            // 
            // よくある質問ToolStripMenuItem
            // 
            this.よくある質問ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.画像を表示したいToolStripMenuItem,
            this.再生プレイヤーを埋め込みたいToolStripMenuItem,
            this.動画再生プレイヤーを埋め込みたいToolStripMenuItem});
            this.よくある質問ToolStripMenuItem.Name = "よくある質問ToolStripMenuItem";
            this.よくある質問ToolStripMenuItem.Size = new System.Drawing.Size(87, 20);
            this.よくある質問ToolStripMenuItem.Text = "よくあるご質問";
            // 
            // 画像を表示したいToolStripMenuItem
            // 
            this.画像を表示したいToolStripMenuItem.Name = "画像を表示したいToolStripMenuItem";
            this.画像を表示したいToolStripMenuItem.Size = new System.Drawing.Size(240, 22);
            this.画像を表示したいToolStripMenuItem.Text = "画像を表示したい";
            // 
            // 再生プレイヤーを埋め込みたいToolStripMenuItem
            // 
            this.再生プレイヤーを埋め込みたいToolStripMenuItem.Name = "再生プレイヤーを埋め込みたいToolStripMenuItem";
            this.再生プレイヤーを埋め込みたいToolStripMenuItem.Size = new System.Drawing.Size(240, 22);
            this.再生プレイヤーを埋め込みたいToolStripMenuItem.Text = "音楽再生プレイヤーを埋め込みたい";
            // 
            // 動画再生プレイヤーを埋め込みたいToolStripMenuItem
            // 
            this.動画再生プレイヤーを埋め込みたいToolStripMenuItem.Name = "動画再生プレイヤーを埋め込みたいToolStripMenuItem";
            this.動画再生プレイヤーを埋め込みたいToolStripMenuItem.Size = new System.Drawing.Size(240, 22);
            this.動画再生プレイヤーを埋め込みたいToolStripMenuItem.Text = "動画再生プレイヤーを埋め込みたい";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(132, 20);
            this.toolStripMenuItem1.Text = "←ツールバー開発中です";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(442, 10);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(175, 12);
            this.linkLabel1.TabIndex = 2;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "情報の追加及び修正(開発者向け)";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.InfoForEgrClicked);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoScrollMargin = new System.Drawing.Size(0, 10);
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(629, 621);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panelAllForm);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Home";
            this.Text = "スッキリわかる Windowsアプリ開発 Reference編 / Home";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.HomeClosing);
            this.Load += new System.EventHandler(this.HomeLoaded);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panelAllForm.ResumeLayout(false);
            this.panelAllForm.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ツールボックスToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem コモンコントロールToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem コンテナーToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem メニューとツールバーToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem データToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem コンポーネントToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 印刷ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ダイアログToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wPF相互運用機能ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem プロパティToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem イベントToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem よくある質問ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 画像を表示したいToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 再生プレイヤーを埋め込みたいToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 動画再生プレイヤーを埋め込みたいToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.LinkLabel linkLabel23;
        private System.Windows.Forms.LinkLabel linkLabel22;
        private System.Windows.Forms.LinkLabel linkLabel21;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.LinkLabel linkLabel5;
        private System.Windows.Forms.LinkLabel linkLabel6;
        private System.Windows.Forms.LinkLabel linkLabel7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.LinkLabel linkLabel9;
        private System.Windows.Forms.LinkLabel linkLabel10;
        private System.Windows.Forms.LinkLabel linkLabel11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.LinkLabel linkLabel13;
        private System.Windows.Forms.LinkLabel linkLabel14;
        private System.Windows.Forms.LinkLabel linkLabel15;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.LinkLabel linkLabel35;
        private System.Windows.Forms.LinkLabel linkLabel34;
        private System.Windows.Forms.LinkLabel linkLabel33;
        private System.Windows.Forms.LinkLabel linkLabel32;
        private System.Windows.Forms.LinkLabel linkLabel31;
        private System.Windows.Forms.LinkLabel linkLabel30;
        private System.Windows.Forms.LinkLabel linkLabel29;
        private System.Windows.Forms.LinkLabel linkLabel28;
        private System.Windows.Forms.LinkLabel linkLabel27;
        private System.Windows.Forms.LinkLabel linkLabel26;
        private System.Windows.Forms.LinkLabel linkLabel25;
        private System.Windows.Forms.LinkLabel linkLabel24;
        private System.Windows.Forms.LinkLabel linkLabel37;
        private System.Windows.Forms.LinkLabel linkLabel36;
        private System.Windows.Forms.LinkLabel linkLabel40;
        private System.Windows.Forms.LinkLabel linkLabel39;
        private System.Windows.Forms.LinkLabel linkLabel38;
        private System.Windows.Forms.LinkLabel linkLabel42;
        private System.Windows.Forms.LinkLabel linkLabel41;
        private System.Windows.Forms.LinkLabel linkLabel44;
        private System.Windows.Forms.LinkLabel linkLabel43;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.LinkLabel linkLabel64;
        private System.Windows.Forms.LinkLabel linkLabel63;
        private System.Windows.Forms.LinkLabel linkLabel62;
        private System.Windows.Forms.LinkLabel linkLabel61;
        private System.Windows.Forms.LinkLabel linkLabel60;
        private System.Windows.Forms.LinkLabel linkLabel59;
        private System.Windows.Forms.LinkLabel linkLabel58;
        private System.Windows.Forms.LinkLabel linkLabel45;
        private System.Windows.Forms.LinkLabel linkLabel46;
        private System.Windows.Forms.LinkLabel linkLabel47;
        private System.Windows.Forms.LinkLabel linkLabel48;
        private System.Windows.Forms.LinkLabel linkLabel49;
        private System.Windows.Forms.LinkLabel linkLabel50;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.LinkLabel linkLabel52;
        private System.Windows.Forms.LinkLabel linkLabel53;
        private System.Windows.Forms.LinkLabel linkLabel54;
        private System.Windows.Forms.LinkLabel linkLabel55;
        private System.Windows.Forms.LinkLabel linkLabel56;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.LinkLabel linkLabel65;
        private System.Windows.Forms.LinkLabel linkLabel66;
        private System.Windows.Forms.LinkLabel linkLabel67;
        private System.Windows.Forms.LinkLabel linkLabel68;
        private System.Windows.Forms.LinkLabel linkLabel69;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.LinkLabel linkLabel73;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ToolStripMenuItem トリガー系ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem linkLabelToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 選択系ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 入力系ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 日付系ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem checkBoxToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem radioButtonToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem listBoxToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem checkedListBoxToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem listViewToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem textBoxToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem maskedTextBoxToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem richTextBoxToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem numericUpDownToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem datetimePickerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem monthCalenderToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 表示系ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem labelToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem pictureBoxToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolTipToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem その他ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem notifyIconToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem progressBarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem webBrowserToolStripMenuItem1;
        private System.Windows.Forms.Panel panelAllForm;
        private System.Windows.Forms.LinkLabel linkLabel71;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}